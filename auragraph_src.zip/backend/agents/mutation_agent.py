"""
agents/mutation_agent.py  — Semantic Kernel 1.x compatible
Adaptive Mutation Loop: rewrites a confusing paragraph based on the student's doubt.
"""

from semantic_kernel import Kernel
from semantic_kernel.functions import KernelArguments
from semantic_kernel.prompt_template import PromptTemplateConfig, InputVariable


MUTATION_PROMPT = """\
You are AuraGraph's Adaptive Mutation Agent.
A student is confused about a specific concept in their study note.

---
ORIGINAL NOTE SECTION:
{{$original_paragraph}}

STUDENT'S DOUBT:
{{$student_doubt}}

---
TASK:
1. Diagnose the student's conceptual gap in one clear sentence.
2. Rewrite the ORIGINAL NOTE SECTION so it directly resolves the doubt.
   - Add an intuition block (💡) explaining WHY it works using an analogy or concrete example.
   - Keep all original formulas (in LaTeX $$...$$). Improve explanations around them.
   - Preserve the Markdown heading if present.
   - Add a `> 📝 **Exam Tip:**` if the doubt reveals a commonly tested misconception.
3. Output exactly TWO sections separated by `|||` (three pipe characters, no spaces around):

<Fully rewritten section that replaces the original>
|||
<One sentence: the diagnosed conceptual gap>

Do NOT write labels like "Rewritten:" or "Gap:". Just the two sections separated by |||.
"""


class MutationAgent:
    def __init__(self, kernel: Kernel):
        self._kernel = kernel
        config = PromptTemplateConfig(
            template=MUTATION_PROMPT,
            template_format="semantic-kernel",
            input_variables=[
                InputVariable(name="original_paragraph", description="The note section to rewrite"),
                InputVariable(name="student_doubt", description="What the student is confused about"),
            ],
        )
        self._fn = kernel.add_function(
            function_name="mutate",
            plugin_name="MutationAgent",
            prompt_template_config=config,
        )

    async def mutate(
        self,
        original_paragraph: str,
        student_doubt: str,
    ) -> tuple[str, str]:
        args = KernelArguments(
            original_paragraph=original_paragraph,
            student_doubt=student_doubt,
        )
        result = await self._kernel.invoke(self._fn, args)
        text = str(result).strip()
        parts = text.split("|||")
        if len(parts) >= 2:
            return parts[0].strip(), parts[1].strip()
        # If separator missing, return the whole thing as the rewrite
        return text, "Student required additional clarification."
