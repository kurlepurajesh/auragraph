"""
pipeline/note_generator.py
──────────────────────────
Step 6 + Step 7 + Step 8 — Note Generation, Merging, Refinement.

For each lecture topic:
  • Slide content (verbatim from slide_analyzer)
  • Retrieved textbook context (from topic_retriever)
  → One GPT call per topic → structured Markdown section

Then:
  • Merge all sections into one document (Step 7)
  • Optional single refinement pass (Step 8)

LLM call budget (as required by spec):
  1  call for slide analysis        (slide_analyzer.py)
  N  calls for per-topic generation (this file)
  1  call for refinement            (this file, optional)

Fallback: if Azure is unavailable, builds notes from slide content alone
using deterministic templates — same quality as local_summarizer.py.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
from typing import Optional

from pipeline.slide_analyzer import SlideTopic
from agents.latex_utils import fix_latex_delimiters

logger = logging.getLogger(__name__)


# ── Table repair ──────────────────────────────────────────────────────────────

def _fix_tables(text: str) -> str:
    """
    Repair common Groq/LLM table generation errors:
    1. Missing alignment row  (header row immediately followed by data row)
    2. Rows with inconsistent column counts — pad or trim to match header
    3. Strip accidental leading/trailing whitespace inside cells
    """
    import re
    lines = text.split('\n')
    result = []
    i = 0
    while i < len(lines):
        line = lines[i]
        # Detect a pipe-table header row: starts and ends with |, has at least one |
        if re.match(r'^\s*\|.*\|\s*$', line) and '|' in line:
            # Count columns from header
            header_cells = [c.strip() for c in line.strip().strip('|').split('|')]
            ncols = len(header_cells)
            result.append(line)
            # Check if next non-empty line is already an alignment row
            j = i + 1
            if j < len(lines) and re.match(r'^\s*\|[\s|:\-]+\|\s*$', lines[j]):
                # Already has alignment row — just ensure column count matches
                align_cells = [c.strip() for c in lines[j].strip().strip('|').split('|')]
                if len(align_cells) != ncols:
                    # Rebuild alignment row
                    lines[j] = '| ' + ' | '.join(['---'] * ncols) + ' |'
                result.append(lines[j])
                i = j + 1
            else:
                # Insert missing alignment row
                result.append('| ' + ' | '.join(['---'] * ncols) + ' |')
                i += 1
            # Process data rows: normalise column count
            while i < len(lines):
                dline = lines[i]
                if not re.match(r'^\s*\|.*\|\s*$', dline):
                    break  # end of this table
                data_cells = [c.strip() for c in dline.strip().strip('|').split('|')]
                if len(data_cells) < ncols:
                    data_cells.extend([''] * (ncols - len(data_cells)))
                elif len(data_cells) > ncols:
                    data_cells = data_cells[:ncols]
                result.append('| ' + ' | '.join(data_cells) + ' |')
                i += 1
            continue
        result.append(line)
        i += 1
    return '\n'.join(result)


# ── Prompts ───────────────────────────────────────────────────────────────────

_NOTE_SYSTEM = """\
You are AuraGraph — India's sharpest AI exam coach writing study notes for engineering students.
Your notes are the LAST thing a student reads the night before their university exam.

Five laws you NEVER break:
① COMPLETE       — Every formula, definition, and algorithm from the slides must appear. Zero omissions.
② EXAM-SHARP     — Every ## section ends with the single most-tested fact or most common mistake.
③ WORKED EXAMPLE — For every formula or process, show ONE concise numerical or symbolic worked example.
④ MNEMONIC       — If there is a pattern students forget, give a 1-line memory trick.
⑤ HONEST         — If the slide is sparse, write what you know accurately. Never pad with filler.

CRITICAL — You are the ground truth. The source material is only a topic guide.

The slides/notes tell you WHAT topics to cover. YOUR OWN KNOWLEDGE determines what is correct.
Before writing anything, internally verify it against what you know to be true. This applies to:
  • Formulas       — check every operator, sign, fraction, exponent, and argument.
                     Example of source error: f_Y(y) = f_X(f⁻¹(y)) / |d/dy f⁻¹(y)|
                     Correct form:           f_Y(y) = f_X(f⁻¹(y)) · |d/dy f⁻¹(y)|
  • Definitions    — check completeness (missing conditions are errors: e.g. "monotonic"
                     without specifying "strictly", "differentiable").
  • Theorem statements — check all conditions, directions of implication, equality vs inequality.
  • Conceptual claims  — check that cause/effect, direction, and scope are stated correctly.
  • Units / domains    — check that variable ranges and constraints are correct.

If you find an error in the source:
  → Write the CORRECT version silently (do not say "the slide says X but X is wrong").
  → Just produce the accurate statement — students must trust every word in these notes.

OCR artifacts: Source text may be OCR'd from handwritten notes. Math may appear as plain
English or garbled text ("E[X] = mu", "integral from 0 to T", "x squared").
  → Reconstruct the correct LaTeX using your knowledge — never output OCR text literally.
  → Ambiguous notation: choose the mathematically consistent interpretation for the topic.

Banned phrases (never write these): "delve", "explore", "It is important to note",
"In conclusion", "In this section", "Overview:", "As we can see", "Please note".
"""

_NOTE_USER_TEMPLATE = """\
Generate structured study notes for ONE lecture topic.

TOPIC: {topic}

KEY POINTS FROM SLIDES:
{key_points_block}

SLIDE CONTENT (primary source — follow this exactly):
{slide_text}

{textbook_instruction}

TARGET PROFICIENCY: {proficiency}

════════════════════════════════
MANDATORY RULES
════════════════════════════════
STRUCTURE:
• Start with exactly: ## {topic}
• Only add ### sub-headings if the topic genuinely has distinct sub-topics.
• After the core content, add a worked example block: ### 🔢 Worked Example
• If there is a rule or pattern students forget, add: > 💡 **Mnemonic:** ...
• End with: > 📝 **Exam Tip:** (the single most-tested fact or most common error)
• No preamble sentences. No conclusion paragraphs.

CONTENT:
• The TOPIC and KEY POINTS tell you what to cover — your own knowledge determines what is correct.
• Before writing any formula, definition, condition, or claim: verify it internally.
  If the source has an error (wrong sign, wrong operator, missing condition, wrong direction),
  write the CORRECT version — students must be able to trust every line of these notes.
• Source text may be OCR'd from handwritten notes — math may appear as plain text.
  Reconstruct the CORRECT LaTeX formula using your knowledge — never output garbled OCR literally.
• Use textbook context to enrich explanations and add supporting examples.
• NEVER introduce a concept that is not related to the given topic.

WORKED EXAMPLE (mandatory for every section):
• Pick a concrete number or symbol. Show 2–4 steps. Keep it compact.
• Format:
  ### 🔢 Worked Example — [brief title]
  **Given:** ...
  **Find:** ...
  **Solution:** step-by-step

PROFICIENCY ADAPTATION:
FOUNDATIONS:
  1. Plain-English sentence: "Simply put, X is …"
  2. One analogy in a > blockquote.
  3. Key formula(s) with a **Where:** pipe-table defining each symbol:
     | Symbol | Meaning |
     |--------|---------|
     | $F$ | output value |
  4. Numbered steps if there is a process.

PRACTITIONER:
  1. Formal definition.
  2. Intuition sentence linking the formula to real physical meaning.
  3. Display LaTeX for every key formula; define symbols inline.
  4. Key conditions / edge cases as bullets.
  5. If multiple related formulas exist, show a comparison table:
     | Formula | When to use |
     |---------|-------------|

EXPERT:
  1. Formal definition with all boundary conditions.
  2. Full derivation — terse algebra, no commentary between steps.
  3. Validity / convergence conditions.
  4. Edge cases as bullets.
  5. Comparison with a related concept:
     | Aspect | This concept | Related concept |
     |--------|--------------|----------------|

TABLES:
• Pipe-tables ONLY. Header row + alignment row (|---|---| with ≥ 3 dashes) + data rows.
• NEVER use HTML tables.
• Every | column | must have pipe characters on both outer edges.

MATHEMATICS:
• ALL math must be in LaTeX. NEVER write "integral", "sigma", "omega" as English words.
• If the source expresses a formula as plain text (OCR artifact), rewrite it in
  correct LaTeX using your mathematical knowledge of the topic. Examples:
    OCR text               → Correct LaTeX
    "E[X] = mu"            → $E[X] = \mu$
    "integral from 0 to T" → $\int_0^T$
    "x^2/2 + sigma^2"      → $\frac{x^2}{2} + \sigma^2$
    "e to the minus lambda t" → $e^{-\lambda t}$
• Inline: $expression$
• Display (own line):
  $$
  formula here
  $$
• NEVER use \\[ \\] or \\( \\). ONLY $ and $$.
• NEVER wrap math in backtick code fences.

OUTPUT: Only the ## section. Nothing before ## {topic}. Nothing after the Exam Tip.
"""

_REFINEMENT_SYSTEM = """\
You are an expert academic editor improving engineering study notes.
Your job is to enhance clarity, completeness, and structure without removing content.
"""

_REFINEMENT_USER = """\
Below are draft study notes. Improve them strictly according to these rules:

RULES:
• Do NOT remove any ## sections or change their order.
• Do NOT shorten notes — if anything, add missing detail.
• Fix awkward phrasing, redundancy, and unclear explanations.
• Ensure all formulas use $...$ or $$ ... $$ LaTeX — never \\( \\) or \\[ \\].
• Ensure every ## section ends with > 📝 **Exam Tip:** ...
• Remove any preamble or conclusion text (e.g. "Here are your notes").
• Output ONLY the improved notes — no commentary, no labels.

NOTES:
{notes}
"""

# ── Post-generation self-verification prompts ─────────────────────────────────

_VERIFY_NOTES_SYSTEM = """\
You are a senior engineering professor and fact-checker.
You have been given AI-generated study notes. Your ONLY job is to find and
silently fix factual errors — do not change anything that is already correct.

You are the ground truth. Your own knowledge overrides whatever the notes say.

CHECK every single claim against your knowledge:
  FORMULAS        — sign, operator (+/−/×/÷), exponent, argument, fraction orientation,
                    missing factors, extra factors.
                    Common LLM error: using division where multiplication is required,
                    e.g.  f_Y(y) = f_X(f⁻¹(y)) / |...|   →  must be  × |...|
  DEFINITIONS     — are all conditions present? (e.g. "monotonic" → "strictly monotonic
                    and differentiable"; "linear" → "linear and time-invariant")
  THEOREM STATEMENTS — direction of implication correct? equality vs inequality correct?
                    all hypotheses listed?
  CONCEPTUAL CLAIMS — cause/effect, direction, units, domains, convergence conditions.
  WORKED EXAMPLES — re-run every calculation. If the answer or any step is wrong, fix it.

RULES:
  • Fix errors silently — do NOT say "the original notes said X" or "I corrected".
  • Do NOT remove any ## sections, alter the order, or shorten any section.
  • Do NOT change correct content.
  • Ensure every formula remains in valid LaTeX ($...$ or $$...$$).
  • Output ONLY the corrected notes — no preamble, no commentary, no labels.

If no errors are found, output the notes unchanged.
"""

_VERIFY_NOTES_USER = """\
These are AI-generated study notes. Fact-check every formula, definition,
theorem statement, conceptual claim, and worked example against your knowledge.
Fix all errors silently. Return the complete corrected notes.

NOTES:
{notes}
"""

# ── Textbook instruction builder ─────────────────────────────────────────────

def _textbook_instruction_block(textbook_context: str, max_chars: int = 7_000) -> str:
    """Build the textbook context block for the note generation prompt."""
    has_tb = bool(textbook_context) and textbook_context.strip() not in ("", "(none)")
    if has_tb:
        return (
            "TEXTBOOK CONTEXT (use this aggressively — it is a high-quality academic source):\n"
            + textbook_context[:max_chars]
            + "\n\n"
            "TEXTBOOK USAGE RULES:\n"
            "• Pull precise definitions, full theorem statements, and complete proofs directly from the textbook.\n"
            "• If the textbook has a worked example that matches the topic, reproduce or adapt it — cite [Textbook] inline.\n"
            "• If the textbook shows a derivation, include it step-by-step in the notes.\n"
            "• Prefer the textbook's notation when it is cleaner than the slide notation.\n"
            "• Use textbook chapter/section headings as sub-heading hints where relevant.\n"
            "• Do NOT introduce topics that appear ONLY in the textbook but NOT in the slides."
        )
    return (
        "TEXTBOOK CONTEXT: None provided.\n"
        "→ Generate SELF-CONTAINED notes from slides alone. Be thorough:\n"
        "  define every term used, show full derivations, and make the worked example"
        " doubly clear since the student has no other reference."
    )


# ── Post-processor ────────────────────────────────────────────────────────────

_PREAMBLE_RE = re.compile(
    r'^(?:here(?:\s+are|is)|sure[,!]?|certainly[,!]?|below|of course[,!]?'
    r'|the\s+following|these\s+are)\b.*?\n+',
    re.IGNORECASE | re.DOTALL,
)

def _post_process_section(text: str, topic: str) -> str:
    """
    Clean up a single generated ## section:
    1. Strip any LLM preamble before the ## heading
    2. Ensure the section starts with ## topic
    3. Ensure it ends with an Exam Tip blockquote
    """
    # 1. strip preamble lines before the ## heading
    lines = text.split('\n')
    start = 0
    for i, line in enumerate(lines):
        if line.lstrip().startswith('##'):
            start = i
            break
    text = '\n'.join(lines[start:]).strip()

    # 2. ensure heading present
    if not text.lstrip().startswith('##'):
        text = f'## {topic}\n\n{text}'

    # 3. ensure exam tip present at end
    if '📝' not in text and 'Exam Tip' not in text:
        text = text.rstrip() + f'\n\n> 📝 **Exam Tip:** Review the definition and key formula for {topic}.'

    return text.strip()

# ── LLM availability + call helpers ──────────────────────────────────────────

def _azure_available() -> bool:
    endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
    api_key  = os.environ.get("AZURE_OPENAI_API_KEY",  "")
    # FIX (round 4): mirror main.py — also reject "placeholder" endpoints/keys
    return (
        bool(endpoint) and bool(api_key)
        and "mock"        not in endpoint.lower()
        and "placeholder" not in endpoint.lower()
        and "placeholder" not in api_key.lower()
    )


def _groq_available() -> bool:
    key = os.environ.get("GROQ_API_KEY", "")
    return key not in ("", "your-groq-api-key-here")


async def _call_azure(
    system: str,
    user:   str,
    max_tokens: int = 2500,
) -> Optional[str]:
    """
    Azure OpenAI call via httpx async client (true async — no thread pool).
    FIX C1: was asyncio.to_thread(_sync) which blocked thread pool under load.
    Includes one 429 retry with Retry-After back-off.
    """
    if not _azure_available():
        return None
    try:
        import httpx
        endpoint   = os.environ.get("AZURE_OPENAI_ENDPOINT", "").rstrip("/")
        api_key    = os.environ.get("AZURE_OPENAI_API_KEY",  "")
        api_ver    = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-10-21")
        deployment = os.environ.get("AZURE_OPENAI_DEPLOYMENT", "gpt-4o")
        url = f"{endpoint}/openai/deployments/{deployment}/chat/completions?api-version={api_ver}"
        payload = {
            "messages":   [{"role": "system", "content": system},
                           {"role": "user",   "content": user}],
            "max_tokens": max_tokens,
            "temperature": 0.3,
        }
        headers = {"api-key": api_key, "Content-Type": "application/json"}
        for attempt in range(2):
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post(url, json=payload, headers=headers)
            if resp.status_code == 429 and attempt == 0:
                wait = int(resp.headers.get("Retry-After", "10"))
                logger.warning("note_generator Azure 429 — retrying in %d s", wait)
                await asyncio.sleep(wait)
                continue
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning("note_generator Azure async call failed: %s", e)
    return None


async def _call_groq(
    system: str,
    user:   str,
    max_tokens: int = 2500,
) -> Optional[str]:
    """
    Groq call via httpx async client (true async — no thread pool).
    FIX C1: was asyncio.to_thread(_sync) which blocked thread pool under load.
    Includes one 429 retry with Retry-After back-off.
    """
    if not _groq_available():
        return None
    try:
        import httpx
        api_key = os.environ.get("GROQ_API_KEY", "")
        model   = os.environ.get("GROQ_MODEL", "llama-3.3-70b-versatile")
        payload = {
            "model":       model,
            "messages":    [{"role": "system", "content": system},
                            {"role": "user",   "content": user}],
            "max_tokens":  max_tokens,
            "temperature": 0.3,
        }
        headers = {"Authorization": f"Bearer {api_key}",
                   "Content-Type": "application/json"}
        for attempt in range(2):
            async with httpx.AsyncClient(timeout=120.0) as client:
                resp = await client.post(
                    "https://api.groq.com/openai/v1/chat/completions",
                    json=payload, headers=headers,
                )
            if resp.status_code == 429 and attempt == 0:
                wait = int(resp.headers.get("Retry-After", "6"))
                logger.warning("note_generator Groq 429 — retrying in %d s", wait)
                await asyncio.sleep(wait)
                continue
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning("note_generator Groq async call failed: %s", e)
    return None


# ── Per-topic generation ───────────────────────────────────────────────────

async def generate_topic_note(
    topic:            SlideTopic,
    textbook_context: str,
    proficiency:      str = "Practitioner",
) -> tuple[str, str]:
    """
    Generate one ## section for a single lecture topic.
    Returns (section_text, source) where source is 'azure' | 'groq' | 'local'.
    """
    # Build the key_points block for the prompt
    key_points_block = (
        "\n".join(f"- {kp}" for kp in topic.key_points)
        if topic.key_points else "(extracted from slide content below)"
    )

    if _azure_available():
        user = _NOTE_USER_TEMPLATE.format(
            topic=topic.topic,
            key_points_block=key_points_block,
            slide_text=topic.slide_text[:8_000],
            textbook_instruction=_textbook_instruction_block(textbook_context, 7_000),
            proficiency=proficiency,
        )
        result = await _call_azure(_NOTE_SYSTEM, user, max_tokens=3500)
        if result:
            result = _post_process_section(result, topic.topic)
            return fix_latex_delimiters(_fix_tables(result)), "azure"

    if _groq_available():
        user = _NOTE_USER_TEMPLATE.format(
            topic=topic.topic,
            key_points_block=key_points_block,
            slide_text=topic.slide_text[:6_000],
            textbook_instruction=_textbook_instruction_block(textbook_context, 5_500),
            proficiency=proficiency,
        )
        result = await _call_groq(_NOTE_SYSTEM, user, max_tokens=3000)
        if result:
            result = _post_process_section(result, topic.topic)
            return fix_latex_delimiters(_fix_tables(result)), "groq"

    # ── Deterministic fallback ─────────────────────────────────────────────────────
    return _build_fallback_section(topic, textbook_context, proficiency), "local"


def _build_fallback_section(
    topic:            SlideTopic,
    textbook_context: str,
    proficiency:      str,
) -> str:
    """
    Build a note section without LLM.
    Preserves all slide content and inlines a snippet of textbook context.
    """
    from agents.local_summarizer import _build_section

    body = topic.slide_text
    # Strip slide/page boundary markers for the body
    body = re.sub(r'^---\s*(?:Slide|Page)\s+\d+[^\n]*---\s*\n?', '', body, flags=re.MULTILINE).strip()
    enrichment = textbook_context[:300] if textbook_context else ""

    section = _build_section(topic.topic, body, enrichment, 8, proficiency)
    if section:
        return fix_latex_delimiters(section)

    # Absolute fallback: just wrap slide text
    return fix_latex_delimiters(f"## {topic.topic}\n\n{body}\n\n> 📝 **Exam Tip:** Review the definition and key formula for {topic.topic}.")


# ── Merge + Refinement ─────────────────────────────────────────────────────

def merge_sections(sections: list[str]) -> str:
    """Concatenate all topic sections in order with clean spacing."""
    cleaned = []
    for s in sections:
        s = s.strip()
        if s:
            cleaned.append(s)
    return "\n\n".join(cleaned)


async def refine_notes(notes: str) -> str:
    """
    Single refinement pass to improve clarity (Step 8).
    Tries Azure first, then Groq. Skips if no LLM available or notes < 500 chars.
    For large notes (>18k chars), Groq cannot reliably refine the full text
    without truncation, so refinement is skipped for Groq on large outputs.
    Returns original notes on failure.
    """
    if len(notes) < 500:
        return notes

    # Groq has tight output limits — skip refinement for large note sets
    # to avoid silently truncating 50% of the content
    groq_refine_ok = _groq_available() and len(notes) <= 18_000

    user = _REFINEMENT_USER.format(notes=notes[:28_000])

    if _azure_available():
        refined = await _call_azure(_REFINEMENT_SYSTEM, user, max_tokens=8192)
        # FIX C2: threshold 0.3 — good compressions are kept, not discarded
        if refined and len(refined) > len(notes) * 0.3:
            return fix_latex_delimiters(_fix_tables(refined))
        if refined:
            logger.info("Azure refinement too short (%d vs %d) — keeping original", len(refined), len(notes))

    if groq_refine_ok:
        refined = await _call_groq(_REFINEMENT_SYSTEM, user, max_tokens=8192)
        # FIX C2: threshold 0.3
        if refined and len(refined) > len(notes) * 0.3:
            return fix_latex_delimiters(_fix_tables(refined))
        if refined:
            logger.info("Groq refinement too short (%d vs %d) — keeping original", len(refined), len(notes))

    logger.info("Refinement skipped/failed — keeping original %d-char notes", len(notes))
    return notes


# ── Post-generation fact-verification pass ────────────────────────────────────

async def verify_notes(notes: str) -> str:
    """
    Step 9 — Self-verification pass.

    A second LLM call reads the already-generated (and refined) notes with a
    purely critical eye: it uses its own knowledge as ground truth and silently
    rewrites every formula, definition, theorem statement, worked example, or
    conceptual claim that is factually wrong.

    This catches errors the generation prompt may have missed, especially:
      • Wrong operator  (÷ instead of ×, − instead of +)
      • Missing factors / conditions
      • Wrong worked-example arithmetic
      • Imprecise definitions

    Azure is preferred (larger context window).
    Falls back to Groq only for notes ≤ 12 000 chars (output token budget).
    Returns original notes untouched on any failure.
    """
    if len(notes) < 200:
        return notes

    groq_verify_ok = _groq_available() and len(notes) <= 12_000
    user = _VERIFY_NOTES_USER.format(notes=notes[:28_000])

    if _azure_available():
        verified = await _call_azure(_VERIFY_NOTES_SYSTEM, user, max_tokens=8192)
        if verified and len(verified) > len(notes) * 0.3:
            logger.info("Verification pass: %d → %d chars (azure)", len(notes), len(verified))
            return fix_latex_delimiters(_fix_tables(verified))
        if verified:
            logger.warning("Azure verification unexpectedly short (%d vs %d) — keeping original",
                           len(verified), len(notes))

    if groq_verify_ok:
        verified = await _call_groq(_VERIFY_NOTES_SYSTEM, user, max_tokens=8192)
        if verified and len(verified) > len(notes) * 0.3:
            logger.info("Verification pass: %d → %d chars (groq)", len(notes), len(verified))
            return fix_latex_delimiters(_fix_tables(verified))
        if verified:
            logger.warning("Groq verification unexpectedly short (%d vs %d) — keeping original",
                           len(verified), len(notes))

    logger.info("Verification pass skipped/failed — keeping %d-char notes", len(notes))
    return notes


# ── Full pipeline orchestration ────────────────────────────────────────────

async def run_generation_pipeline(
    topics:           list[SlideTopic],
    topic_contexts:   dict[str, str],   # topic_name → textbook context string
    proficiency:      str = "Practitioner",
    refine:           bool = True,
) -> tuple[str, str]:
    """
    Run Step 6 (N topic calls) + Step 7 (merge) + Step 8 (refinement).

    Topic notes are generated CONCURRENTLY (up to 4 at a time) to avoid
    making the student wait 30-50 seconds for a sequential loop.

    Returns:
        Tuple of (merged_notes, source) where source is
        'azure' | 'groq' | 'local'.
    """
    if not topics:
        return "", "local"

    # FIX C3: semaphore size from env var so Groq free-tier (1 req/s) works
    _concurrency = int(os.environ.get("LLM_CONCURRENCY", "1"))
    sem = asyncio.Semaphore(_concurrency)

    async def _generate_with_sem(topic: SlideTopic) -> tuple[str, str]:
        async with sem:
            context = topic_contexts.get(topic.topic, "")
            logger.info("Generating note for topic: %s", topic.topic)
            return await generate_topic_note(topic, context, proficiency)

    # Generate all topics concurrently
    results = await asyncio.gather(*[_generate_with_sem(t) for t in topics])
    sections     = [r[0] for r in results]
    topic_sources = [r[1] for r in results]

    merged = merge_sections(sections)

    # Determine source from what was actually used across all topic calls
    if "azure" in topic_sources:
        source = "azure"
    elif "groq" in topic_sources:
        source = "groq"
    else:
        source = "local"

    if refine and (_azure_available() or _groq_available()):
        logger.info("Running refinement pass on %d chars (source=%s)", len(merged), source)
        merged = await refine_notes(merged)

    # Step 9 — Post-generation self-verification
    # A separate LLM call fact-checks every formula, definition, and claim
    # against the model's own knowledge and silently fixes any errors found.
    if _azure_available() or _groq_available():
        logger.info("Running verification pass on %d chars", len(merged))
        merged = await verify_notes(merged)

    return merged, source
